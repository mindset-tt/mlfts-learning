'use strict';

export default {
  extends: ['@cybozu/eslint-config/presets/kintone-customize-es5']
};
