jQuery.noConflict();

(function($, PLUGIN_ID) {
  'use strict';

  // kintone.events.on('app.record.index.show', function() {
  //   var config = kintone.plugin.app.getConfig(PLUGIN_ID);

  //   var spaceElement = kintone.app.getHeaderSpaceElement();
  //   if (spaceElement === null) {
  //     throw new Error('The header element is unavailable on this page');
  //   }
  //   var fragment = document.createDocumentFragment();
  //   var headingEl = document.createElement('h3');
  //   var messageEl = document.createElement('p');

  //   messageEl.classList.add('plugin-space-message');
  //   messageEl.textContent = config.message;
  //   headingEl.classList.add('plugin-space-heading');
  //   headingEl.textContent = 'Hello kintone plugin!';

  //   fragment.appendChild(headingEl);
  //   fragment.appendChild(messageEl);
  //   spaceElement.appendChild(fragment);
  // });



  var changeSalesStageFieldColor = function(params) {
    console.log(params);
    var element = params.element;
    var value = params.value;
    var backgroundColor;
    var fontWeight;
    switch (value) {
      case 'Banana':
        backgroundColor = '#FED101';
        break;
      case 'Apple':
        backgroundColor = '#66b447';
        break;
      case 'Mango':
        backgroundColor = '#f4bb44';
        break;
      case 'Olive':
        backgroundColor = '#7DCEA0';
        break;
      case 'Papaya':
        backgroundColor = '#F4D03F';
        break;
      default:
        break;
    }

    if (backgroundColor) {
      element.style.backgroundColor = backgroundColor;
    }
    if (fontWeight) {
      element.style.fontWeight = fontWeight;
    }
  };

  kintone.events.on('app.record.detail.show', function(event) {
    var record = event.record;
    var salesStage = record.Code_Color.value;
    var salesStageElement = kintone.app.record.getFieldElement('Code_Color');
    changeSalesStageFieldColor({element: salesStageElement, value: salesStage});
    return event;
  });

  kintone.events.on('app.record.index.show', function(event) {
    var records = event.records;
    var salesStageElements = kintone.app.getFieldElements('Code_Color');
    for (var i = 0; i < records.length; i++) {
      var record = records[i];
      var salesStage = record.Code_Color.value;
      var salesStageElement = salesStageElements[i];
      changeSalesStageFieldColor({element: salesStageElement, value: salesStage});
    }
    return event;
  });


})(jQuery, kintone.$PLUGIN_ID);
